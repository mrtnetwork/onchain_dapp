import * as wc from './utils.mjs';





async function connect() {
    const { topic, provider } = await wc.initWalletConnect();
    const accounts = await provider.request({ method: "eth_requestAccounts", params: [] });
    return { provider, accounts };
}

async function personalSign() {
    const { accounts, provider } = await connect();
    const params = ["0x0c0c0c", accounts[0]];
    const signature = await provider.request({ method: "personal_sign", params });
    console.log("signature: " + Buffer.from(signature).toString('hex'))

}
window.connect = connect
window.personalSign = personalSign