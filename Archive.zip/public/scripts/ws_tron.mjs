let _wallet;
function createCompleter() {
    let resolve, reject;
    const promise = new Promise((res, rej) => {
        resolve = res;
        reject = rej;
    });
    return { promise, resolve, reject };
}
function appIsReady(params) {
    const event = new CustomEvent('wallet-standard:app-ready', {
        detail: {
        }
    });
    window.dispatchEvent(event);

}

async function getWallet() {

    if (_wallet) return _wallet;
    const completer = createCompleter();
    window.addEventListener("wallet-standard:register-wallet", function s(e) {
        e.detail({
            register: function _(params) {
                if (params !== undefined && params.name != undefined && params.name == 'OnChain') {
                    completer.resolve(params)
                }
            }
        })
    });
    appIsReady();
    _wallet = await completer.promise;
    console.log("wallet init: " + JSON.stringify(_wallet.features))
    return _wallet;

}


async function connect() {
    const wallet = await getWallet();
    let { accounts } = await wallet.features["tron:connect"].connect();
    console.log("accouts: " + accounts[0].chains)
    accounts = accounts.filter(account => account.chains.includes("tron:0xcd8690dc"));
    console.log(accounts.length)

    return { accounts, wallet };
}
async function getTronWeb() {
    if (window.tron !== undefined && window.tron && window.tron.tronWeb) {
        return window.tron.tronWeb
    }
    return new TronWeb({
        fullHost: 'https://api.shasta.trongrid.io/'
    });
}
async function signMessage() {
    const { wallet, accounts } = await connect();
    const params = {
        message: Buffer("im test.",'utf-8').toString("hex"),
        account: accounts[0]
    }
    const { signature } = await await wallet.features["tron:signMessage"].signMessage(
        params
    );
    console.log("signaturre: " + Buffer.from(signature).toString("hex"))
}
async function transferTrx() {
    const { wallet, accounts } = await connect();
    const tronweb = await getTronWeb();
    const transaction = await tronweb.transactionBuilder.sendTrx("TNPeeaaFB7K9cmo4uQpcU32zGK8G1NYqeL", 1, accounts[0].address);
    // const poroto = tronweb.utils.transaction.txJsonToPb(transaction);
    const params = {
        transaction: transaction,
        account: accounts[0]
    }
    const signedTransaction = await await wallet.features["tron:signTransaction"].signTransaction(
        params
    );
    let result = await tronweb.trx.sendRawTransaction(signedTransaction);
    console.log("tx: " + JSON.stringify(result));
}
async function listenOnEvents() {
    const wallet = await getWallet();
    await wallet.features["tron:events"].on('change',
        (p) => console.log("account changed: " + p.accounts.map((e) => e.address + " ,") + " chains: " + p.chains)
    );
}
window.listenOnEvents = listenOnEvents
window.connect = connect
window.signMessage = signMessage
window.transferTrx = transferTrx