function startAppKit() {
    const appkit = createAppKit({
        projectId: "392db477d2a3f837141f08aa2bd40583",
        manualWCControl: true,
        universalProvider: provider,
        networks: [mainnet],
        metadata: {
            name: "React App",
            description: "App to test WalletConnect network",
            url: location.origin,
            icons: [],
        },
        showWallets: false,
        enableEIP6963: false, // Disable 6963 by default
        enableInjected: false, // Disable injected by default
        enableCoinbase: false, // Default to true
        enableWalletConnect: true,
        features: {
            email: false,
            socials: false,
        },
    });
    appkit.open();
}
async function initWalletConnect() {
    const provider = await UniversalProvider.init({
        projectId: '392db477d2a3f837141f08aa2bd40583',
    });
    console.log("init done!");
    provider.on("display_uri", (uri) => {
        console.log("URI for WalletConnect modal:", uri);
        // Open modal with URI or call your `appkit.open()` here
    });

    // 2. Listen for new session (initial connection)
    provider.on("connect", (session) => {
        console.log("New session connected!", session);
        // Wallet has connected via modal
    });

    // 3. Optional: listen to session updates (e.g. chain/account change)
    provider.on("session_update", (session) => {
        console.log("Session updated:", session);
    });

    // 4. Optional: wallet sends events (e.g. chainChanged or accountsChanged)
    provider.on("session_event", (event) => {
        console.log("Session event:", event);
    });

    // 5. Listen for session deletion (e.g. wallet disconnects)
    provider.on("disconnect", () => {
        console.log("Wallet disconnected");
    });
    console.log("init done!");
    const existingPairing = provider.client.pairing.getAll();
    const activeSessions = provider.client.session.getAll();
    // console.log(JSON.stringify(existingPairing));
    const onchainSession = activeSessions.find(
        (session) => session.peer.metadata.name.toLowerCase() === "onchain"
    );
    provider.session = onchainSession;
    console.log("session: " + provider.session);
    if (onchainSession == null) {
        createAppKit();
    }
    console.log(JSON.stringify(onchainSession));
    return { topic: onchainSession.pairingTopic, provider }

}
async function connectToWallet({ topic, provider }) {
    const client = await provider.connect({
        pairingTopic: topic,
        namespaces: {
            eip155: {
                methods: [
                    'eth_sendTransaction',
                    'eth_signTransaction',
                    'eth_sign',
                    'personal_sign',
                    'eth_signTypedData',
                ],
                chains: ['eip155:1'],
                events: ['chainChanged', 'accountsChanged']
            },
        },
    });
    console.log("client done!");
}

export { initWalletConnect };