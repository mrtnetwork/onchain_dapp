const { SigningStargateClient, Registry,
    encodePubkey,
    makeAuthInfoBytes,
    makeSignDoc,
    makeSignBytes,
    coins,
    TxBody, AuthInfo, Any,
    TxRaw,
    encodeSecp256k1Pubkey } = Cosmos;

let _wallet;
function createCompleter() {
    let resolve, reject;
    const promise = new Promise((res, rej) => {
        resolve = res;
        reject = rej;
    });
    return { promise, resolve, reject };
}
function appIsReady(params) {
    const event = new CustomEvent('wallet-standard:app-ready', {
        detail: {
        }
    });
    window.dispatchEvent(event);

}

async function getWallet() {
    if (_wallet) return _wallet;
    const completer = createCompleter();
    window.addEventListener("wallet-standard:register-wallet", function s(e) {
        e.detail({
            register: function _(params) {
                if (params !== undefined && params.name != undefined && params.name == 'OnChain') {
                    completer.resolve(params)
                }
            }
        })
    });
    appIsReady();
    _wallet = await completer.promise;
    return _wallet;

}
async function listenOnEvents() {
    const wallet = await getWallet();
    await wallet.features["cosmos:events"].on('change',
        (p) => console.log("account changed: " + p.accounts.map((e) => e.address + " ") + " chains: " + p.chains)
    );
}

async function connect() {
    const wallet = await getWallet();
    let { accounts } = await wallet.features["cosmos:connect"].connect();
    return { accounts, wallet };
}

async function signAndSendAminoTransaction() {
    const { accounts, wallet } = await connect();
    let { amino, direct } = await wallet.features["cosmos:signer"].signer("provider");
    const rpcUrl = "https://rpc.provider-sentry-02.ics-testnet.polypore.xyz"
    const signingClient = await SigningStargateClient.connectWithSigner(
        rpcUrl,
        amino
    );
    const providerAccounts = await amino.getAccounts()
    const r = await signingClient.sendTokens(
        providerAccounts[0].address,
        "cosmos1etkgdknzysw5v89hjqm3ply5m0r4zdpwnjszr2",
        [
            {
                denom: "uatom",
                amount: "100000",
            },
        ],
        {
            amount: [{ denom: "uatom", amount: "1000" }],
            gas: "200000",
        },
    )
    const jsonString = JSON.stringify(r, (key, value) =>
        typeof value === "bigint" ? value.toString() + "n" : value
    );
    console.log("response: " + jsonString)

}

async function signAndSendDirectTransaction() {
    const { accounts, wallet } = await connect();
    let { amino, direct } = await wallet.features["cosmos:signer"].signer("provider");
    const rpcUrl = "https://rpc.provider-sentry-02.ics-testnet.polypore.xyz"
    const signingClient = await SigningStargateClient.connectWithSigner(
        rpcUrl,
        direct
    );
    const providerAccounts = await direct.getAccounts()
    console.log("provider accounts: " + providerAccounts)
    const r = await signingClient.sendTokens(
        providerAccounts[0].address,
        "cosmos1etkgdknzysw5v89hjqm3ply5m0r4zdpwnjszr2",
        [
            {
                denom: "uatom",
                amount: "100000",
            },
        ],
        {
            amount: [{ denom: "uatom", amount: "1000" }],
            gas: "200000",
        },
    )
    const jsonString = JSON.stringify(r, (key, value) =>
        typeof value === "bigint" ? value.toString() + "n" : value
    );
    console.log("response: " + jsonString)

}

async function addNewChain() {
    const { accounts, wallet } = await connect();
    const params = {
        chainId: 'babajaga-1',
        rpc: 'https://rpc-testnet.c4e.io/',
        hrp: 'c4e'

    };
    const r = await wallet.features["cosmos:addNewChain"].addNewChain(params);

}
async function signMessage() {
    const { accounts, wallet } = await connect();
    if (!accounts) return;
    const params = {
        message: Uint8Array.from([1, 2, 3, 4]),
        account: accounts[0]
    }
    const { signature } = await await wallet.features["cosmos:signMessage"].signMessage(
        params
    );
    console.log("signature: " + signature)
}
window.listenOnEvents = listenOnEvents
window.connect = connect
window.signAndSendAminoTransaction = signAndSendAminoTransaction
window.signAndSendDirectTransaction = signAndSendDirectTransaction
window.addNewChain = addNewChain
window.signMessage = signMessage
