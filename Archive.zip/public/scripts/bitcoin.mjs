let _wallet;
function createCompleter() {
    let resolve, reject;
    const promise = new Promise((res, rej) => {
        resolve = res;
        reject = rej;
    });
    return { promise, resolve, reject };
}
function appIsReady(params) {
    const event = new CustomEvent('wallet-standard:app-ready', {
        detail: {
        }
    });
    window.dispatchEvent(event);

}

async function getWallet() {
    if (_wallet) return _wallet;
    const completer = createCompleter();
    window.addEventListener("wallet-standard:register-wallet", function s(e) {
        e.detail({
            register: function _(params) {
                if (params !== undefined && params.name != undefined && params.name == 'OnChain') {
                    completer.resolve(params)
                }
            }
        })
    });
    appIsReady();
    _wallet = await completer.promise;
    return _wallet;

}

async function listenOnEvents() {
    const wallet = await getWallet();
    await wallet.features["bitcoin:events"].on('change', function name({ accounts, chains }) {
        if (accounts !== undefined && accounts) {
            console.log("accounts change: " + accounts.length)
        }
        if (chains !== undefined && chains) {
            console.log("chains change: " + chains.length)
        }

    });
}


async function listenOnAllEvents() {
    const wallet = await getWallet();
    await wallet.features["standard:events"].on('change', function name({ accounts, chains }) {
        if (accounts !== undefined && accounts) {
            console.log("all accounts change: " + accounts.length)
        }
        if (chains !== undefined && chains) {
            console.log("all chains change: " + chains.length)
        }

    });
}

async function sendTx() {
    const wallet = await getWallet();
    const r = await wallet.features["bitcoin:connect"].connect();
    let account = r.accounts.filter(account => account.chains.includes("bitcoincash:testnet"));
    const outputs = [
        { script: "6a0c746869732069732074657374", value: "1000" },
        { address: "bchtest:prn6dq4ncxykmz0rle5lq4avvjn29qzv2unt7rutn8", value: "1000" },
        { address: "bchtest:rvj73m0c7lxx6u4n3kjvn08c23tcye65lefp6x0a0k9ud4lxxf4ucp02jedur", value: "1000" },
        { script: "aa20db2a1ab949de125a00bacecbde1de68fc20e36ceaf34017642e6d453759834f687", value: "1000" },


    ]
    const { txId } = await wallet.features["bitcoin:sendTransaction"].sendTransaction(
        { accounts: account, outputs }
    );
}
async function disconnect() {
    const wallet = await getWallet();
    await wallet.features["bitcoin:disconnect"].disconnect();
}
async function connect(network) {
    if (network === undefined || network == null) {
        network = "testnet4"
    }
    const wallet = await getWallet();
    let { accounts } = await wallet.features["bitcoin:connect"].connect();
    accounts = accounts.filter(account => account.chains.includes("bitcoin:" + network));
    // console.log("accounts: " + JSON.stringify(accounts))
    return { accounts }
}
async function signMessage() {
    const wallet = await getWallet();
    const { signature } = await wallet.features["bitcoin:signPersonalMessage"].signPersonalMessage(
        { account: "2N5v1QHwpkM5TizqFTU4TEvv91rxcW1ku9W", message: Buffer.alloc(10, 0), messagePrefix: "jafar2x" }
    );
}
async function signPsbt() {
    const wallet = await getWallet();
    const sign = await wallet.features["bitcoin:signTransaction"].signTransaction(
        await _buildPsbt("testnet4")
    );
    const psbt = bitcoin.Psbt.fromBase64(sign.psbt);
    const rawTx = psbt.extractTransaction().toHex();
    return rawTx;

}
async function signAndSendPsbt() {
    const rawTx = await signPsbt();
    console.log("got raw tx: " + rawTx);
    await _broadcastTx(rawTx);

}
async function psbtBch() {
    const wallet = await getWallet();
    const r = await wallet.features["bitcoin:connect"].connect();

    const testnetAccounts = r.accounts.filter(account => account.chains.includes("bitcoincash:testnet"));
    const sign = await wallet.features["bitcoin:signTransaction"].signTransaction(
        { accounts: testnetAccounts, psbt: psbtTx }
    );
    const psbt = bitcoin.Psbt.fromBase64(sign.psbt);
    return psbt.extractTransaction().toHex();
    console.log("got psbt: " + sign.psbt.length);
    const parse = parsePsbt(sign.psbt);
    console.log("parse done: " + parse)

}



async function _buildPsbt(network) {
    const wallet = await getWallet();
    let { accounts } = await wallet.features["bitcoin:connect"].connect();
    accounts = accounts.filter(account => account.chains.includes("bitcoin:" + network));
    if (accounts.length == 0) {
        alert("no " + network + " accounts found.");
        return;
    }
    let addresses = [];
    for (let index = 0; index < accounts.length; index++) {
        const addrs = await wallet.features["bitcoin:getAccountAddresses"].getAccountAddresses(
            { account: accounts[index].address }
        );
        for (let addr = 0; addr < addrs.length; addr++) {
            addresses.push(addrs[addr]);
        }
    }
    console.log(JSON.stringify(addresses));

    let addressesUtxos = [];
    for (let i = 0; i < addresses.length; i++) {
        const address = addresses[i];
        let url = "https://mempool.space/testnet4/api/address/" + address.address + "/utxo"
        let response = await fetch(url);
        console.log("isok: " + response.ok)
        if (!response.ok) throw Error("Unable to retrive address utxos.")
        if (response.ok) {
            const utxos = await response.json();
            for (let j = 0; j < utxos.length; j++) {
                const utxo = {
                    address: address,
                    hash: utxos[j].txid,
                    index: utxos[j].vout,
                    value: utxos[j].value,
                    // size: Buffer.from(address.script, "hex").byteLength,
                    isWitness: _isWitness(address.type),
                    isP2tr: _isP2tr(address.type),
                    isMultisig: _isMultisig(address.type),
                    isP2sh: _isP2sh(address.type),
                    type: address.type,
                    script: Buffer.from(address.script, "hex"),
                    publicKey: Buffer.from(address.publicKey, 'hex'),
                    ...(_isMultisig(address.type) ? {} : { publicKey: Buffer.from(address.publicKey, 'hex') }),
                    ...(address.redeemScript ? { redeemScript: Buffer.from(address.redeemScript, "hex") } : {}),
                    ...(address.witnessScript ? { witnessScript: Buffer.from(address.witnessScript, "hex") } : {}),
                    ...(_isP2tr(address.type) ? { tapInternalKey: Buffer.from(address.publicKey, 'hex').subarray(1) } : {})
                };
                addressesUtxos.push(utxo);

            }
        }
    }
    console.log("utxos done ?!" + addressesUtxos.length);
    if (addressesUtxos.length == 0) {
        console.log("no utxos");
        return;
    }
    // console.log(JSON.stringify(addressesUtxos));
    let psbtInputs = [];
    for (let i = 0; i < addressesUtxos.length; i++) {
        let utxo = addressesUtxos[i];
        const input = await _buildInputs(utxo);
        console.log("build inputs done?");
        psbtInputs.push(input);

    }
    const totalInputValue = addressesUtxos.reduce((sum, input) => {
        return sum + (input.value || 0)
    }, 0)
    console.log("here ?!");
    const n = bitcoin.networks.testnet
    console.log("here ?!2 " + JSON.stringify(psbtInputs));
    const psbt = new bitcoin.Psbt({ network: n });
    psbt.addInputs(psbtInputs);
    console.log("here ?!2");
    const value = 100000;
    const userInput = "mju61fosB2S8zYbxAuoMeufjVMnhZ2NvFv";
    const payment = bitcoin.address.toOutputScript(userInput, n);
    const out = {
        value: value,
        address: userInput,
        script: payment
    }
    console.log("here ?3!");
    const changeAddress = addressesUtxos[0].address.address;
    console.log("here ?!4");
    const change = {
        value: 1,
        address: changeAddress,
        script: bitcoin.address.toOutputScript(changeAddress, n)
    }
    psbt.addOutput(out);
    console.log("done here?");
    const vsize = _estimateInputSize(addressesUtxos, [out, change]).vsize;
    const fee = vsize * 2;
    const changeAmount = totalInputValue - value - fee;
    if (change < 0) throw Error("Not enough found.");
    change.value = changeAmount
    psbt.addOutput(change);
    return { accounts, psbt: psbt.toBase64() }
}


function _isP2tr(type) {
    return type == "P2TR"
}

function _isP2sh(type) {
    return type.includes("P2SH")
}
function _isMultisig(type) {
    return type.includes("P2SH") || type.includes("P2WSH")
}
function _isWitness(type) {
    switch (type) {
        case "P2WPKH":
        case "P2WSH":
        case "P2TR":
        case "P2SH/P2WSH":
        case "P2SH/P2WPKH":
            return true
        default:
            return false;
    }
}

async function _getTx(txId, network) {
    const url = "https://mempool.space/testnet4/api/tx/" + txId + "/hex";
    console.log("url: " + url);
    let tx = await fetch(url);
    if (tx.ok) {
        let txHex = await tx.text();
        return Buffer.from(txHex, "hex");
    }
    throw Error("Unable to retrive tx: " + txId)

}
async function _broadcastTx(rawTx) {
    const response = await fetch("https://mempool.space/testnet4/api/tx", {
        method: "POST",
        headers: {
            "Content-Type": "text/plain"
        },
        body: rawTx
    });
    if (!response.ok) throw new Error(`HTTP error ${response.status}`);
    const txId = await response.text();
    console.log("txId: " + txId);
    alert("txId: " + txId)

}


function _varIntSize(n) {
    if (n < 0xfd) return 1;
    if (n <= 0xffff) return 3;
    return 5;
}

function _estimateInputSize(inputs, outputs) {
    const signatureSize = 73;
    const schnorSigSize = 65;
    const isSegwit = inputs.some(e => e.isWitness);
    const version = 4;
    const locktime = 4;
    const markerAndFlag = isSegwit ? 2 : 0;

    const inputsLen = _varIntSize(inputs.length);
    const outputsLen = _varIntSize(outputs.length);

    // Calculate total size of inputs (scriptSig etc)
    let totalInputSize = 0;
    for (const input of inputs) {
        totalInputSize += 36; // outpoint

        if (input.isWitness) {
            let scriptSigLength = 0;
            if (input.isP2sh && input.redeemScript) {
                scriptSigLength = input.redeemScript.byteLength;
            }
            totalInputSize += _varIntSize(scriptSigLength) + scriptSigLength;
            continue;
        }

        if (input.isMultisig) {
            const scriptSigLength = signatureSize * 3 + input.redeemScript.byteLength + 1;
            totalInputSize += _varIntSize(scriptSigLength) + scriptSigLength;
            continue;
        }

        if (input.publicKey) {
            const scriptSigLength = signatureSize + input.publicKey.byteLength;
            totalInputSize += _varIntSize(scriptSigLength) + scriptSigLength;
        } else {
            totalInputSize += 1; // empty scriptSig length
        }
    }

    // Calculate total size of outputs
    let totalOutputSize = 0;
    for (const output of outputs) {
        totalOutputSize += 8; // amount
        totalOutputSize += _varIntSize(output.script.byteLength) + output.script.byteLength;
    }

    // Calculate witness size
    let witnessSize = 0;
    if (isSegwit) {
        for (const input of inputs) {
            if (!input.isWitness) continue;

            let witnessStackCount = 0;
            let witnessStackSize = 0;

            if (input.isMultisig) {
                witnessStackCount = 5; // OP_0 + 3 sigs + witnessScript
                witnessStackSize += 1; // OP_0 empty push

                for (let i = 0; i < 3; i++) {
                    witnessStackSize += _varIntSize(signatureSize) + signatureSize;
                }

                witnessStackSize += _varIntSize(input.witnessScript.byteLength) + input.witnessScript.byteLength;
            } else if (input.isP2tr) {
                witnessStackCount = 1;
                witnessStackSize += _varIntSize(schnorSigSize) + schnorSigSize;
            } else {
                witnessStackCount = 2; // sig + pubkey
                witnessStackSize += _varIntSize(signatureSize) + signatureSize;
                witnessStackSize += _varIntSize(input.publicKey.byteLength) + input.publicKey.byteLength;
            }

            witnessSize += _varIntSize(witnessStackCount) + witnessStackSize;
        }
    }
    // Base size excludes witness and marker/flag
    const baseSize =
        version +
        inputsLen +
        totalInputSize +
        outputsLen +
        totalOutputSize +
        locktime;
    // Total size includes marker/flag and witness
    const totalSize = baseSize + markerAndFlag + witnessSize;

    // Virtual size = (3 * base_size + total_size) / 4 rounded up
    const vsize = Math.ceil((3 * baseSize + totalSize) / 4);

    return { totalSize, baseSize, witnessSize, vsize };
}



async function _buildInputs(info) {
    const address = info.address
    const witnessScript = address.witnessScript
    const redeemScript = address.redeemScript;
    const type = address.type;
    const publicKey = address.publicKey;
    const value = info.value;

    let nonWitnessUtxo = null
    const isWitness = _isWitness(type)
    const isP2tr = _isP2tr(type);
    console.log("is come ?!");
    console.log("hash: " + info.hash);
    if (!isWitness) {
        nonWitnessUtxo = await _getTx(info.hash)
    }
    console.log("is witness: " + isWitness)
    const input = {
        hash: info.hash,
        index: info.index,
        porCommitment: "please sign this psbt."

    };
    if (isWitness) {
        input["witnessUtxo"] = {
            script: Buffer.from(address.script, 'hex'),
            value: value
        }
    }
    if (redeemScript !== undefined && redeemScript != null) {
        input["redeemScript"] = Buffer.from(redeemScript, "hex")
    }
    if (witnessScript !== undefined && witnessScript != null) {
        input["witnessScript"] = Buffer.from(witnessScript, "hex")
    }
    if (isP2tr) {
        input["tapInternalKey"] = Buffer.from(publicKey, 'hex').subarray(1)
    }
    if (nonWitnessUtxo != null) {
        input["nonWitnessUtxo"] = nonWitnessUtxo
    }
    return input;
}

window.psbtBch = psbtBch
window.signPsbt = signPsbt
window.signAndSendPsbt = signAndSendPsbt
window.sendTx = sendTx
window.signMessage = signMessage
window.disconnect = disconnect
window.connect = connect
window.listenOnEvents = listenOnEvents
window.listenOnAllEvents = listenOnAllEvents
